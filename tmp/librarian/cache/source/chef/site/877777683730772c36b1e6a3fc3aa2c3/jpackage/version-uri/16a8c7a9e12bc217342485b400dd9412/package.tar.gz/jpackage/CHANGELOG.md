## v1.0.0:

* [COK-2127] - Use `platform_family` to add OS support

## v0.10.0:

* Initial released version.
